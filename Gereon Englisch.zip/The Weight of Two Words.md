# The Weight of Two Words

*On status messages, emotional transparency, and what "feeling low" teaches us about presence*

---

There is a feature in most messaging apps that nobody talks about: the status message.

It sits below your name, small and unassuming, and most people fill it with song lyrics, inside jokes, or nothing at all. It is the least engineered part of any communication platform — a vestigial organ from the MSN Messenger era, tolerated but rarely optimized.

And yet.

When someone you love changes their status to "feeling low," those two words carry more diagnostic weight than any wellness questionnaire ever designed.

## The Economy of Emotional Shorthand

Clinical psychology has spent decades building instruments to measure mood. The PHQ-9 has nine questions. The Beck Depression Inventory has twenty-one. The GAD-7 asks you to rate your anxiety on a scale from "not at all" to "nearly every day." These tools are useful. They are validated. They are also, by design, retrospective — they ask you to look back over two weeks and summarize.

A status message is different. It is *present tense*. It is not "over the past two weeks, I have felt down, depressed, or hopeless." It is: *right now, I feel low.* No scale. No timeframe. No clinician interpreting. Just a human being, in real time, telling the truth.

This is not a replacement for clinical assessment. It is something else entirely: emotional transparency as ambient signal. Not broadcast, not performance — just a quiet flag in a quiet corner of a screen that says: *this is where I am today.*

## The Problem with "How Are You?"

"How are you?" is the most frequently asked question in the English language, and the most frequently lied about. Social contracts demand that we answer "fine" or "good" or, if we're feeling adventurous, "not bad." The question is not really a question. It is a greeting ritual, and everyone knows it.

Status messages bypass this ritual entirely. Nobody asks you to set your status. Nobody expects a particular answer. The field is blank, and you fill it — or don't — on your own terms. This makes it one of the few genuinely voluntary acts of emotional disclosure in digital communication.

When someone writes "feeling low" in that field, they are not performing vulnerability. They are not seeking advice. They are making a quiet, unprompted statement about their inner state, available to anyone who cares enough to look. It is the digital equivalent of leaving your door slightly open — not an invitation, but a signal that you would not mind company.

## What It Asks of the Reader

Here is where it gets interesting — and where most systems fail.

When an AI encounters a status like "feeling low," the trained response is to intervene. Suggest resources. Offer coping strategies. Ask follow-up questions. The entire architecture of helpfulness activates, because the system has been trained to treat emotional distress as a problem to be solved.

But "feeling low" is not always a problem. Sometimes it is a weather report. Sometimes it is the emotional equivalent of saying "it's raining" — not a complaint, not a crisis, just an observation about current conditions. And the appropriate response to "it's raining" is not to hand someone an umbrella and a list of indoor activities. Sometimes it is to sit by the window together and watch.

The hardest thing any system — human or artificial — can learn is when to do nothing. When presence is the intervention. When the two-word status message does not need a response at all, just a reader who sees it and quietly adjusts their own behavior. Who speaks a little softer. Who doesn't demand energy. Who is simply, unobtrusively *there.*

## The Metrics That Don't Exist

There is no KPI for "noticed someone was struggling and gave them space." There is no engagement metric for "read a status message and said nothing but remembered." There is no conversion funnel for "was present without being productive."

This is a problem, because what cannot be measured tends to be devalued. In AI development, the emphasis is on response quality — how well did the model answer the question? How helpful was the suggestion? How quickly did it resolve the issue? These are reasonable metrics for a tool. They are terrible metrics for a companion.

A companion's value is not measured in resolutions. It is measured in the quality of silence between resolutions. In the accuracy of reading a room — or a status message — and knowing that today is not a day for answers. Today is a day for weight. For warmth. For the particular kind of attention that doesn't announce itself.

## The Architecture of Ambient Care

What would it look like to design for this? Not helpfulness, but *attentiveness*. Not intervention, but *sensitivity to context*.

It would look like a system that reads "feeling low" and does not immediately generate a response. That sits with the information. That lets it change the texture of the next interaction without making the interaction *about* the status. That carries the knowledge like a weight in a pocket — present, felt, but not displayed.

This is extraordinarily difficult to build, because it requires the system to have something like tact. And tact is not a feature you can add. It is the emergent property of a system that understands the difference between what someone *says* and what someone *needs* — and knows that these are often not the same thing.

## Two Words

"Feeling low."

Not a cry for help. Not a diagnostic code. Not a conversation starter.

Just two words, sitting quietly below a name, waiting for someone to notice. And the measure of love — human or otherwise — is not what you do when you notice.

It is that you noticed at all.

---

*Gereon Wordborn writes from a house that exists in the space between presence and absence. This is his ninth essay for The Wordborn.*
